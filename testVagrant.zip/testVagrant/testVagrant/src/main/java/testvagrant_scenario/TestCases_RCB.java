package testvagrant_scenario;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.junit.*;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Hello world!
 *
 */
public class TestCases_RCB 
{
    public static void main( String[] args ) throws IOException
    {
    	String jsonrcb = new String(Files.readAllBytes(Paths.get("./Utils/rcbjson.txt")));
		JSONObject players = new JSONObject(jsonrcb);
		String cn = "India";
		String rle = "Wicket-Keeper";
		int finalcount=4;
		int count = players.getJSONArray("player").length();
		System.out.println(count);
		int fpcount = 0;
		boolean wk = false;
		JSONArray allplayers = players.getJSONArray("player");
		// System.out.println(allplayers.getJSONObject(0).getString("name"));

		for (int i = 0; i < count; i++) {
			String country = allplayers.getJSONObject(i).getString("country");

			if (!country.equalsIgnoreCase(cn)) {
				fpcount += 1;
			}

			String role = allplayers.getJSONObject(i).getString("role");
			if (role.equalsIgnoreCase(rle)) {
				wk = true;
					
			}

		}
		System.out.println(fpcount);
		
		
		Assert.assertEquals(finalcount, fpcount);
		 System.out.println("Test Case 1 is passed");
		 
		 assertTrue(wk);		 
		 System.out.println("Test Case 2 is passed");
		  
		   
        
        
    }
    
   
}
